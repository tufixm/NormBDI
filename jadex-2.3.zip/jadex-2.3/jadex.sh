#!/bin/sh
java -jar lib/jadex-platform-standalone-launch-2.3.jar