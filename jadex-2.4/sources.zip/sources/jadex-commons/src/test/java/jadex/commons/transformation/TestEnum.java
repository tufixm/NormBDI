package jadex.commons.transformation;

/**
 * 
 */
public enum TestEnum
{
	A, B, C;
}
