package jadex.commons;

/**
 *  Marker interface for remotable objects.
 */
//@Reference
public interface IRemotable
{
}
