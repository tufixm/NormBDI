package jadex.commons.meta;

public interface IPropertyMetaData {
	
	/**
	 * @return the type of the property
	 */
	public Class getType();
	
	
	
}
