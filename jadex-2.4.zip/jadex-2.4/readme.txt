Jadex
Copyright (C) 2002-2013 Lars Braubach, Alexander Pokahr, Kai Jander
University of Hamburg

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.



Privacy Statement for using Jadex Relay Server

By default, each Jadex platform uses Jadex Relay, a discovery and messaging
service provided by the Jadex Team. As a result, information about your use
of Jadex (including your IP address) will be transmitted to and stored by
Jadex Relay on servers in Germany. The Jadex Team will use this information
only for the purpose of evaluating your use of Jadex and compiling reports
on Jadex activity for being presented to other Jadex users.
You may refuse the use of the Jadex Relay by selecting the appropriate start 
options, however please note that if you do this you may not be able to use
the full functionality of Jadex. By using Jadex, you consent to the processing
of Jadex usage data about you by the Jadex Team in the manner and for the
purposes set out above.